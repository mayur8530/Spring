package com.tourism;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourismApplicationTests {

	@Test
	void contextLoads() {
	}

}
